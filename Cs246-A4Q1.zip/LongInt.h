#ifndef __LONGINT_H__
#define __LONGINT_H__
#include "Expression.h"

class LongInt:public Expression {
   int item; //num
   public:
		LongInt(int);
   	~LongInt();
   	void prettyprint();
   	int evaluate();
   	std::string getop();
};
#endif
