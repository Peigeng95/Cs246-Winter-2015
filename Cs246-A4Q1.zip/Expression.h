#ifndef __EXPRESSION_H__
#define __EXPRESSION_H__
#include <cstring>
#include <iostream>

class Expression {
   protected:
   std::string oper;//protected oper
   public:
   	Expression(std::string);
   	virtual void prettyprint() = 0;//pure virtual
   	virtual int evaluate() = 0;//pure virtual
   	void setop(std::string);
   	virtual ~Expression()=0;//pure virtual
};

#endif
