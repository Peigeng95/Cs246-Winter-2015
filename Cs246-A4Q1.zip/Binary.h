#ifndef __BINARY_H__
#define __BINARY_H__
#include "Expression.h"

class Binary: public Expression {
   Expression *ex1;//first expression
   Expression *ex2;//second expression
   public:
		Binary(std::string oper); //ctor
   	~Binary();	//dtor
   	void prettyprint();
   	int evaluate();
   	std::string getop();
   	void setex1(Expression *exp);
   	void setex2(Expression *exp);
};
#endif
