#include "Expression.h"
#include "Binary.h"
#include "Unary.h"
#include "LongInt.h"
#include <sstream>
#include <cstdlib>

using namespace std;

int main() {
   Expression *arr[10]; //expression arr with 10 capacity
   string oper="empty"; //the oper
	int place = 0; // index on the arr
   for(int i = 0; i < 10; i++) {//set all to NULL
      arr[i] = NULL;
   }
   int temp;//every num
   while(true) {
      cin >> oper;//read op
      if (cin.eof()){ //End of file
			break;
		}
      stringstream ss(oper);
      if (ss >> temp) {
         LongInt *myint = new LongInt(temp);
         arr[place] = myint;
         place++;
         if(place > 10) {
            for(int i = 0; i < 10; i++) {
               delete arr[i];
            }
            cerr << "Stack overflow" << endl;
            delete myint;
            return 0;
      	}
      }
      else {
			if((oper == "+") || (oper == "-") || (oper == "*") || (oper == "/")) {
            Binary *mybinary = new Binary(oper);
            Expression *e1 = arr[place - 2];
            Expression *e2 = arr[place - 1];
            arr[place - 1] = NULL;
            place = place - 2;
            mybinary->setex1(e1);//pop
            mybinary->setex2(e2);//pop
            arr[place] = mybinary;//replace
            place++;
         }
         else {//((oper == "NEG") || (oper == "ABS"))
            Unary *myunary = new Unary(oper);
            Expression *temp = arr[place - 1];
            myunary->setop(temp);
            arr[place - 1] = myunary;
         }
      }
   }
	if(arr[0] == NULL){
		return 0;
	}
   arr[0]->prettyprint();
   cout << endl;
   cout << "= " << arr[0]->evaluate() << endl;
   delete arr[0];
}
