#ifndef __UNARY_H__
#define __UNARY_H__
#include "Expression.h"

class Unary:public Expression {
   Expression *ex;//expression
   public:
   	Unary(std::string);
   	~Unary();
   	void prettyprint();
   	int evaluate();
   	std::string getop();
   	void setop(Expression *);
};

#endif
