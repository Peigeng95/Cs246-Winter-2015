#include "Binary.h"

using namespace std;

//ctor
Binary::Binary(string oper):Expression(oper),ex1(NULL), ex2(NULL){}

//dtor
Binary::~Binary() {
   delete ex1;
   delete ex2;
}

//get op
string Binary::getop() {
   return oper;
}

//print
void Binary::prettyprint() {
   if (getop() == "+") {
      cout << "(";
      ex1->prettyprint();
      cout << " + ";
      ex2->prettyprint();
      cout << ")";
   }
   else if (getop() == "-") {
      cout << "(";
      ex1->prettyprint();
      cout << " - ";
      ex2->prettyprint();
      cout << ")";
   }
   else if (getop() == "*") {
      cout << "(";
      ex1->prettyprint();
      cout  << " * ";
      ex2->prettyprint();
      cout << ")";
   }
   else{// (geop() == "/")
      cout << "(";
      ex1->prettyprint();
      cout  << " / ";
      ex2->prettyprint();
      cout << ")";
   }
}

//evaluate
int Binary::evaluate() {
   if (this->getop() == "+") {
      return (ex1->evaluate() + ex2->evaluate());
   }
   else if (this->getop() == "-") {
      return (ex1->evaluate() - ex2->evaluate());
   }
   else if (this->getop() == "*") {
      return (ex1->evaluate() * ex2->evaluate());
   }
   else{//(this->getop() == "/")
      return (ex1->evaluate() / ex2->evaluate());
   }
}   

//set expressions   
void Binary::setex1(Expression *ex) {
   ex1 = ex;
}
void Binary::setex2(Expression *ex) {
   ex2 = ex;
}
