#include "Expression.h"

using namespace std;

//ctor
Expression::Expression (string oper):oper(oper) {}

//dtor
Expression::~Expression() {}

//setop
void Expression::setop(string op){
	this->oper = op;
}
