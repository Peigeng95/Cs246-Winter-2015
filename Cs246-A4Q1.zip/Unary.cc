#include "Unary.h"

using namespace std;

//ctor
Unary::Unary(string oper):Expression(oper),ex	(NULL) {}

//dtor
Unary::~Unary() {
   delete ex;
}

//print
void Unary::prettyprint() {
	if (getop() == "NEG") {
      cout << "-" ;
      ex->prettyprint();
   }
   else{//(getop() == "ABS")
      cout << "|" ;
      ex->prettyprint();
      cout<< "|";
   }
}

//evaluate
int Unary::evaluate() {
   if(this->getop() == "NEG") {
      return -ex->evaluate();
   }
   else{// (getop() == "ABS")
      if(ex->evaluate() >= 0) {
         return ex->evaluate();
      }
      else {
         return -ex->evaluate();
      }
   }
}

//get oper
string Unary::getop() {
   return oper;
}

//set op
void Unary::setop(Expression *ex1) {
   ex = ex1;
}
