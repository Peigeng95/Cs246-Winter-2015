#include "LongInt.h"

using namespace std;

//ctor
LongInt::LongInt(int item):Expression("empty"),item(item) {}

//dtor
LongInt::~LongInt() {}

//print
void LongInt::prettyprint() {
   cout << item;
}

//evaluate
int LongInt::evaluate() {
   return item;
}

//get oper
string LongInt::getop() {
   return oper;
}

